#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "_/lib/__ENV.h"
#include "_/lib/__WP.h"



char *  REQUIRE_USERNAME(){
    FILE * PR;
    static char FIELD[50];
    PR=popen(USER_NAME,"r");
    fgets(FIELD,sizeof(FIELD),PR);
    strip(FIELD);
    if(strlen(FIELD) == 0 || strlen(FIELD) <2 || strlen(FIELD) > 12){
        system(WARN_USER);
        REQUIRE_USERNAME();
    }
    
    fclose(PR);
    return FIELD;
    
}

char *  REQUIRE_PASSWORD(){
    FILE * PR;
    static char FIELD[50];
    PR=popen(USER_PASS,"r");
    fgets(FIELD,sizeof(FIELD),PR);
    strip(FIELD);
    if(strlen(FIELD) == 0 || strlen(FIELD) <2 || strlen(FIELD) > 8){
        system(WARN_PASS);
        REQUIRE_PASSWORD();
    }
    
    fclose(PR);
    return FIELD;
    
}

void AT_SYS_INTERFACE(){
    FILE * output;
    char FIELD[50];
    output=popen(MENU_AT_SYS,"r");

    fgets(FIELD,sizeof(FIELD),output);
    if(strcmp(FIELD,"NEW    USER") == 0){
        GAUGE_AT_SYS_2
        /*CREATE NEW ACCOUNT*/
        char * tlt  = REQUIRE_USERNAME();
        char * t_c  = REQUIRE_PASSWORD();
        AT_SYS_INTERFACE();
    }
    fclose(output);
    
}
int root_access(){
    
    FILE * output;
    output=popen(CRED_BOX_AT_SYS,"r");

    if(output != NULL){
        
        char FIELD[50];
        fgets(FIELD,sizeof(FIELD),output);
        if(strcmp("root",FIELD) == 0){
            GAUGE_AT_SYS_2
            AT_SYS_INTERFACE();
        }else{
            system(WARNING_F_CRED);
            root_access();
        }
    }
    fclose(output);
}
int main(){

    GAUGE_AT_SYS_1
    root_access();
    return 0;
}